<div class="footer">
    <div class="wrapper">
         <p class="footer-last">2022 All rights reserved, Food House. Developed by - <a href="#"> Deepak Yadav</a></p>
      </div>
   </div>

</body>
</html>