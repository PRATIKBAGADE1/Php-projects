<?php  include('partials/menu.php');   ?>

 <div class="main-content">
     <div class="wrapper">
         <h1>Manage Order</h1>

        
          <table class="tbl-full">
             <tr>
                <th>S.N</th>
                <th>Full Name</th>
                <th>Username</th>
                <th>Actions</th>
             </tr>

             <tr>
                <td>1.</td>
                <td>Deepak Yadav</td>
                <td>deepakyadav123</td>
                <td>
                   <a href="#" class="btn-secondary" >Update Order</a>
                   <a href="#" class="btn-danger">Delete Order</a>
                </td>
             </tr>

             <tr>
                <td>2.</td>
                <td>Deepak Yadav</td>
                <td>deepakyadav123</td>
                <td>
                   <a href="#" class="btn-secondary" >Update Order</a>
                   <a href="#" class="btn-danger">Delete Order</a>
                </td>
             </tr>

             <tr>
                <td>3.</td>
                <td>Deepak Yadav</td>
                <td>deepakyadav123</td>
                <td>
                   <a href="#" class="btn-secondary" >Update Order</a>
                   <a href="#" class="btn-danger">Delete Order</a>
                </td>
             </tr>

             


          </table>


     </div>
 </div>




<?php  include('partials/footer.php');   ?>